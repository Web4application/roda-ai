# Submission policy

Following the spirit of promoting open source software, you should provide a reference to your github repository as first priority. If links are pointed to non open source sites ( ie : your company website ), you will be deprioritized first and categorized into [cloud service](https://github.com/currentsapi/awesome-vector-search#cloud-service).

